package programming2Assignment1;
import java.util.Random;//use for suppor random

/**
 * this call represent  a slot machine, randomly get 3 number and compare it to calculate 
 * credit
 * it has a houseCredit keep check increase of credit in house
 * token credit for player
 * also a random for get random number
 * @author Zijian Zhao  ID: 17971280
 *
 */
public class SlotMachine {
	
	private static Random generator;
	private static int tokenCredit;
	private static int houseCredit;
	
	SlotMachine()
	{
		this.tokenCredit=0;
		this.generator=new Random();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SlotMachine slotMachine  =new SlotMachine();
		slotMachine.topUpTokens(50);
		slotMachine.getTokenBalance();
		slotMachine.pullLever();
		slotMachine.getTokenBalance();
		slotMachine.pullLever(10);
		slotMachine.getTokenBalance();
		slotMachine.cashOut();
	}
	
	//this method will allow top up credit
	public void topUpTokens(int tokens)
	{
		tokenCredit+=tokens;
	}
	
	//this method will allow player case out
	public int cashOut()
	{
		System.out.println("Now cash out: "+tokenCredit);
		return tokenCredit;
	}
	
	//this method will start the slot machine
	public static void pullLever()
	{
		if(tokenCredit>1)
		{
			tokenCredit-=1;
			houseCredit+=1;
			System.out.println("Inputed 1 token");
			int x = generator.nextInt(9)+1;
			int y = generator.nextInt(9)+1;
			int z = generator.nextInt(9)+1;
			System.out.println(x+" "+y+"  "+z);
			if(x==0&&y==0&&z==0)
			{
				tokenCredit+=500;
				System.out.println("Super Jackpot Winner");
			}
			else if(x==y&&y==z)
			{
				tokenCredit+=50;
				System.out.println("Jackpot Winner");
			}
			else if(x==y)
			{	
				tokenCredit+=1;
				System.out.println("Free Spin");
			}
			else
			{
				System.out.println("Bad luck");
			}			
		}
		else
		{
			System.out.println("You do not have enouth money");
		}
	}
	
	
	//this method is overloaded, it allow player to insert credit
	public static void pullLever(int insert)
	{
		if(tokenCredit>=insert)
		{
			tokenCredit-=insert;
			houseCredit+=insert;
			System.out.println("Inputed "+insert+" token");
			int x = generator.nextInt(9)+1;
			int y = generator.nextInt(9)+1;
			int z = generator.nextInt(9)+1;
			System.out.println(x+" "+y+"  "+z);
			if(x==0&&y==0&&z==0)
			{
				tokenCredit+=(insert*500);
				System.out.println("Super Jackpot Winner");
			}
			else if(x==y&&y==z)
			{
				tokenCredit+=(insert*50);
				System.out.println("Jackpot Winner");
			}
			else if(x==y)
			{	
				tokenCredit+=insert;
				System.out.println("Free Spin");
			}
			else
			{
				System.out.println("Bad luck");
			}			
		}
		else
		{
			System.out.println("You do not have enouth money");
		}
	}

	//return the balance of the player
	public static int getTokenBalance()
	{
		System.out.println("Your credit is "+ tokenCredit);
		return tokenCredit;
	}

	//this will return the house credit
	public static int getHouseCredit() {
		return houseCredit;
	}
		
}
