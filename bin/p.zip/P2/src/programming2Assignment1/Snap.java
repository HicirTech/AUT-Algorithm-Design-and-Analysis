package programming2Assignment1;

import java.util.ArrayList; //use for support pile
import java.util.Collections;// use for support random 
import java.util.Scanner;// use for user input

/**
 * this class will play a snap game
 * use can select from menu to draw or call snap
 * @author Zijian Zhao  ID: 17971280
 *
 */
public class Snap {
	private static int playerTurn; // player turn keep increase every draw or snap
	public static int player_1; 
	public static int player_2;
	private static Deck player1Deck;
	private static Deck player2Deck;
	private static ArrayList<Card> pile; 
	private static Scanner scanner;
	
	// this will set up desks for players each have 26 card
	Snap()
	{
		scanner = new Scanner(System.in);
		setupPlayerDecks();
	}
	
	// this will start the snap game
	public static void main(String[] args) {
		Snap game =  new Snap();
		System.out.println("Game start!");
		do {
			System.out.println("This turn is for "+(((playerTurn%2))+1));
			System.out.println("What do you want?\n "
					+ "1.Player 1 Snap 2.Player 1 draw\n"
					+ " 3.Player 2 Snap 4.Player 2 draw");
			int input =scanner.nextInt();
			switch(input)
			{
				case 1:	
					snap(1);
					break;
				case 2:
					drawCard(1);
					break;
				case 3:	
					snap(2);
					break;
				case 4:
					drawCard(2);
					break;
			}
			System.out.println(player1Deck);
			System.out.println(player2Deck);
			playerTurn++;
		}while(true);
			
	}
	
	// this will check is it a snap,
	// if yes, return true
	// if card less than 2 is not able to compare return false
	// if not same return false
	private static boolean checkSnap(){
		if(pile.size()>=2)
		{
			return pile.get(pile.size()-1).getValue()==pile.get(pile.size()-2).getValue();
		}
		else
		{
			return false;
		}
	}
	
	//return how many turns played
	public static int getPlayerTurn()
	{
		return playerTurn;
	}
	
	// return how many cards each player have
	public static int getPlayerCardsRemaining(int player)
	{
		if(player==1)
		{
			return player1Deck.getDeckSize();
		}
		else
		{
			return player2Deck.getDeckSize();
		}
	}
	
	//check is the game finish by calling isWinner method
	//if one player is winner, game is finished
	public static boolean hasGameFinished()
	{	
		return (isWsinner(1)||isWsinner(2));//any one is true, this will be true
	}
	
	//check opposing player still have card or not, if not this player is win
	public static boolean isWsinner(int player)
	{
		if(player==1)
		{
			return player2Deck.getDeckSize()==0;
		}
		else if(player==2)
		{
			return player1Deck.getDeckSize()==0;
		}
		else
		{
			return false;
		}
	}
	
	//play can call snap by use this method
	//this will check if it is snap, if yes, take cards from pile
	//else opposing player take cards from pile
	//if it is no card in pile, it will show pile is empty
	//return it is a snap or not
	public static boolean snap(int player)
	{
		boolean result = checkSnap();//save result before any change
		System.out.println("Player"+player+" is calling snap!");
		System.out.println("It is a snap? [" +checkSnap()+"]");
		if(checkSnap())
		{
				System.out.println("Player "+player+" take cards");
				pickupPile(player);
				
		}
		else
		{
			if(pile.size()!=0)
			{
				if(player==1)
				{
					System.out.println("Player 2 get a card");
					pickupPile(2);
					
				}
				else
				{
					System.out.println("Player 1 get a card");
					pickupPile(1);
				}
			}
			else
			{
				System.out.println("pile is empty, not body get card!");
			}
		}
		return result;
	}
	
	
	//this method will put all cards in pile into that player's deck
	private static void pickupPile(int player)
	{
		Collections.shuffle(pile);
		while(pile.size()!=0)
		{	
			if(player==1)
			{
				player1Deck.placeCard(pile.get(0));
			
			}
			else
			{
				player2Deck.placeCard(pile.get(0));
		
			}
			System.out.println("player " +player + "get card: [" +pile.remove(0)+"]");
		}
	}
	
	//this will put card to pile
	private static Card drawCard(int player)
	{
		if(player == 1)
		{
			pile.add(0,player1Deck.drawCard());
		}
		else
		{
			pile.add(0,player2Deck.drawCard());
		}
		System.out.println("Player+"+player+" draw "+pile.get(0)+" to the pile");
		
		return pile.get(0);
	}

	//this method will set up the deck
	private void setupPlayerDecks()
	{
		playerTurn=0;
		pile=new ArrayList<>();
		player1Deck=new Deck(false);
		player2Deck=new Deck(false);
		Deck temp = new Deck(true);
		temp.shuffle();
		for(int i=0;i!=26;i++)
		{
			player1Deck.placeCard(temp.drawCard());
			player2Deck.placeCard(temp.drawCard());
		}
		
		System.out.println("Table SET!");
	}
}
