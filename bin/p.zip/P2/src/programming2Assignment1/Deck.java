package programming2Assignment1;

import java.util.ArrayList;// use for support random shuffles algorithm 
import java.util.Arrays; // use for out put array toString
import java.util.Random;//  use for support random shuffles algorithm 

/**
 * this class is represent a Deck object in real world,
 * it have a card array which which contain 52 cards
 * it have a deskSize constantly check how many card in the deck
 * it have a max size of 52
 * @author Zijian Zhao  ID: 17971280
 *
 */
public class Deck {
	private ArrayList<Integer> RamdonList;
	private Card[] desk;
	private int deskSize;
	public final int MAX_SIZE = 52;
	
	//default constructor will call true constructor by use this keyword
	Deck()
	{
		this(true);
	}
	
	//this constructor will take a boolean variable as parameter
	//if true set size to 51 and initialize full deck
	//if false will get a new array of card size is 52 but not initialize the cards
	Deck(boolean fullDesk)
	{		
		if(fullDesk)
		{
			this.deskSize=51;
			this.initialiseFullDeck();
		}
		else
		{
			this.deskSize=0;
			this.desk=new Card[this.MAX_SIZE];
		}
	}
	
	//initialize full deck assigning card suits and values by for loop
	private void initialiseFullDeck()
	{
		int count = 0;
		this.desk=new Card[this.MAX_SIZE];
		for(int outIndex=1;outIndex!=5;outIndex++)
		{
			for(int index=0;index!=13;index++)
			{
				this.desk[count]=new Card(outIndex,index+1);
				count++;
			}
		}
	}
	
	//this method will draw a card and move the element 1 left
	//also will correct deskSize
	//if no card left will return null
	public Card drawCard()
	{
		if(deskSize>=0)
		{
			Card temp = this.desk[0];
			for(int i=1;i<this.desk.length;i++)
			{
				desk[i-1]=desk[i];
			}
			this.desk[deskSize]=null;
			this.deskSize--;
			return temp;
		}
		else
		{
			System.out.println("Stack empty");
			return null;
		}
	}
	
	//deck array first element is null, it means no card left
	public boolean hasCardRemaining()
	{
		return this.desk[0]!=null;
	}

	//return how many card still in deck
	public int getDeckSize()
	{
		return this.deskSize;
	}
	
	//put a new card to the end of the array
	//also will correct the deskSize
	public void placeCard(Card card)
	{
		if(this.deskSize<0)
		{
			this.deskSize=0;
		}
		
		if(this.deskSize!=52)
		{
			this.desk[deskSize]=card;
			this.deskSize++;
		}
	}
	
	//this is a random shuffles algorithm 
	public void shuffle()
	{
		Card[] temp=new Card[52];
		Random getRam = new Random();
		RamdonList = new ArrayList<Integer>();
		int currentA=getRam.nextInt(52);
		
		//below
		//if a random number never show up before
		//it will take this number as index and take value 
		//from the array save into temp
		//if a random number show up before
		//get a new ramdom never show up befor
		while(RamdonList.size()!=this.MAX_SIZE)
		{
			if(!RamdonList.contains(currentA))
			{
				temp[RamdonList.size()]=desk[currentA];
				RamdonList.add(currentA);
			}
			else
			{
				currentA=getRam.nextInt(52);
			}
		}
		this.desk=temp;
	}
	
	//this method will print out the array
	public String toString()
	{
		return Arrays.toString(desk);
	}
	
}
