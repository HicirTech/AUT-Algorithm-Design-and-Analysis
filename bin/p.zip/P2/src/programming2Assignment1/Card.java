package programming2Assignment1;

/**
 * this is a comparable card object, it have suit and value, represent a real world porker card 
 * this class to String will return suit + value e.g. H3
 * @author Zijian Zhao  ID: 17971280
 *
 */
@SuppressWarnings("rawtypes") // in compareTo method this will be case to Card object
public class Card implements Comparable  {

	private int suit;//suit of this card
	private int value;// value of this card
	
	Card(int suit,int value) // this can be use to set value, and suit
	{
		this.value=value;
		this.suit=suit;
	}
	
	// this method will conver suit number to letter
	// e.g. 4 -> H
	private String suitToLetter(int suitInNumber)
	{	
		String result = "";
		switch(suitInNumber)
		{
			case(4):result = "H";break;
			case(3):result = "D";break;
			case(2):result = "C";break;
			case(1):result = "S";break;
		}
		return result;
	}
	
	//this method will compare two cards, return 1 if it is bigger, -1 for smaller, 0 for same
	@Override // override the compareTo method in the comparable interface
	public int compareTo(Object o) {
		if(this.isSamesuit((Card)o))
		{
			return this.value-((Card)o).value;
		}
		else
		{
			if(((Card)o).suit>this.suit)
			{
				return -1;
			}
			else
			{
			
				return 1;
			}
		}
	}


	//this will check is two Card is in same suit
	private boolean isSamesuit(Card card)
	{
		return this.suit==card.suit;
	}

	//getter for suit
	public int getSuit() {
		return suit;
	}

	//getter for value
	public int getValue() {
		return value;
	}
	//this will out the card like H3 or S4
	public String toString()
	{
		return (this.suitToLetter(this.suit)+this.value);
	}
	
}
