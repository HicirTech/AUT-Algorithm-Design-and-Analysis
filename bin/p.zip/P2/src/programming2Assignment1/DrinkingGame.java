package programming2Assignment1;

/**
 * this class will do a drink game, play 1 and play 2 will keep picking card from deck
 * until desk is empty
 * it will compare two cards in every turn and increase the countShot
 * @author Zijian Zhao  ID: 17971280
 *
 */
public class DrinkingGame {

	public static void main(String[] args) {
		Deck desk = new Deck(true);
		int countShotPlayer1=0;
		int countShotPlayer2=0;
		desk.shuffle();
		for(int i=0;i!=26;i++)
		{
			Card player1Pick = desk.drawCard();
			Card player2Pick = desk.drawCard();
			System.out.println("Player 1 pick"+player1Pick);
		
			System.out.println("Player 2 pick"+player2Pick);
			
			
			if(player1Pick.compareTo(player2Pick)>0)
			{
				countShotPlayer2++;
			}
			else
			{
				countShotPlayer1++;
			}
		}
		System.out.println("Player drink : "+countShotPlayer1+" shots");
		System.out.println("Player drink : "+countShotPlayer2+" shots");
	}
}
